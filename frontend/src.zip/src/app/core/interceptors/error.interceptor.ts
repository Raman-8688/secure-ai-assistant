// src/app/core/interceptors/error.interceptor.ts
import { HttpInterceptorFn, HttpErrorResponse } from '@angular/common/http';
import { inject } from '@angular/core';
import { catchError, throwError } from 'rxjs';
import { NetworkService } from '../services/network.service';

export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  const networkService = inject(NetworkService);

  return next(req).pipe(
    catchError((error: HttpErrorResponse) => {
      // No internet connection
      if (!networkService.isOnline) {
        return throwError(() => ({
          userMessage: 'No internet connection. Please check your network and try again.',
          type: 'network',
        }));
      }

      // Network-level failure
      if (error.status === 0) {
        return throwError(() => ({
          userMessage: 'Unable to connect to the server. Please try again in a moment.',
          type: 'server_down',
        }));
      }

      // ✅ Extract error message from backend response
      let userMessage = 'Something went wrong. Please try again.';
      
      // Console log to debug what we're getting
      console.log('Error object:', error);
      console.log('Error.error:', error.error);

      // Try to get error message from error.error
      if (error.error) {
        // Case 1: error.error is an object with 'error' property
        if (error.error.error && typeof error.error.error === 'string') {
          userMessage = error.error.error;
        }
        // Case 2: error.error is an object with 'message' property
        else if (error.error.message && typeof error.error.message === 'string') {
          userMessage = error.error.message;
        }
        // Case 3: error.error is an object with 'error' property that has 'message'
        else if (error.error.error && error.error.error.message) {
          userMessage = error.error.error.message;
        }
        // Case 4: error.error is a string
        else if (typeof error.error === 'string') {
          // Try to parse if it's JSON string
          try {
            const parsed = JSON.parse(error.error);
            if (parsed.error && typeof parsed.error === 'string') {
              userMessage = parsed.error;
            } else if (parsed.message && typeof parsed.message === 'string') {
              userMessage = parsed.message;
            } else {
              userMessage = error.error; // Use as is
            }
          } catch {
            // Not JSON, use as is
            userMessage = error.error;
          }
        }
        // Case 5: error.error has nested structure
        else if (error.error.errorResponse) {
          const nested = error.error.errorResponse;
          userMessage = nested.error || nested.message || userMessage;
        }
      }

      // Clean up the message - remove any extra quotes or brackets
      if (userMessage) {
        // Remove surrounding quotes if present
        userMessage = userMessage.replace(/^["']|["']$/g, '');
        // Remove surrounding braces if present
        userMessage = userMessage.replace(/^\{|\}$/g, '');
        // Remove "error:" prefix if present
        userMessage = userMessage.replace(/^error:\s*/i, '');
      }

      // If it's 401, override with auth message
      if (error.status === 401) {
        userMessage = 'Your session has expired. Please log in again.';
      }

      // If it's 403, override with forbidden message
      if (error.status === 403) {
        userMessage = 'You do not have permission to perform this action.';
      }

      console.log('Final error message:', userMessage);

      return throwError(() => ({
        userMessage: userMessage,
        status: error.status,
        type: error.status === 401 ? 'auth' : 'error',
      }));
    }),
  );
};