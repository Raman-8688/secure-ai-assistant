import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router, RouterLink } from '@angular/router';
import { AuthService } from '../../../core/services/auth.service';
import { VerifyEmailRequest } from '../../../core/models/auth.model';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';

@Component({
  selector: 'app-verify-email',
  standalone: true,
  imports: [CommonModule, FormsModule, RouterLink, MatSnackBarModule],
  templateUrl: './verify-email.component.html',
  styleUrls: ['./verify-email.component.css']
})
export class VerifyEmailComponent implements OnInit {
  email = '';
  otp = '';
  isLoading = false;
  isResending = false;
  message = '';
  errorMessage = '';
  isVerified = false;

  constructor(
    private authService: AuthService,
    private route: ActivatedRoute,
    private router: Router,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    this.email = this.route.snapshot.queryParamMap.get('email') || '';
    
    if (!this.email) {
      this.router.navigate(['/register']);
    }
  }

  verifyEmail(): void {
    this.message = '';
    this.errorMessage = '';

    const request: VerifyEmailRequest = {
      email: this.email.trim(),
      otp: this.otp.trim()
    };

    if (!request.otp) {
      this.errorMessage = 'Please enter the OTP';
      return;
    }

    if (request.otp.length !== 6) {
      this.errorMessage = 'OTP must be 6 digits';
      return;
    }

    this.isLoading = true;

    this.authService.verifyEmail(request).subscribe({
      next: (response: string) => {
        this.isLoading = false;
        this.isVerified = true;
        this.message = response;
        
        // Show success snackbar
        this.snackBar.open(response, 'Close', {
          duration: 3000,
          panelClass: ['success-snackbar']
        });

        setTimeout(() => {
          this.router.navigate(['/login']);
        }, 2000);
      },
      error: (error) => {
        this.isLoading = false;
        // Use the error message from backend
        this.errorMessage = error.userMessage || 'OTP verification failed. Please try again.';
        
        // Show error snackbar
        this.snackBar.open(this.errorMessage, 'Close', {
          duration: 5000,
          panelClass: ['error-snackbar']
        });
      }
    });
  }

  resendOtp(): void {
    this.message = '';
    this.errorMessage = '';

    if (!this.email.trim()) {
      this.errorMessage = 'Email is required';
      return;
    }

    this.isResending = true;

    this.authService.resendOtp({ email: this.email.trim() }).subscribe({
      next: (response: string) => {
        this.isResending = false;
        this.message = response;
        this.otp = '';
        
        this.snackBar.open(response, 'Close', {
          duration: 3000,
          panelClass: ['success-snackbar']
        });
      },
      error: (error) => {
        this.isResending = false;
        this.errorMessage = error.userMessage || 'Failed to resend OTP';
        
        this.snackBar.open(this.errorMessage, 'Close', {
          duration: 5000,
          panelClass: ['error-snackbar']
        });
      }
    });
  }

  goToLogin(): void {
    this.router.navigate(['/login']);
  }
}